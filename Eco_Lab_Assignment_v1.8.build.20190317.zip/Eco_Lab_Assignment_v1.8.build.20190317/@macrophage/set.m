function c=set(c,prop_name,val)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

% Standard function to allow insertion of memory parameters from macrophage object

switch prop_name
   
case 'food'
   c.food=val;
case 'pos'
    c.pos=val; 
case 'age'
   c.age=val;
case 'speed'
   c.speed=val; 
case 'last_breed'
   c.last_breed=val; 
otherwise 
   error('invalid field name')
end

