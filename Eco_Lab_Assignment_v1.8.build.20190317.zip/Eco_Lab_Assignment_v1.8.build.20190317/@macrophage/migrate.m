function [agt]=migrate(agt,cn)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

%Migration functions for class macrophage
%agt=macrophage object
%cn - current agent number

global IT_STATS N_IT ENV_DATA PARAM MESSAGES

%N_IT is current iteration number
%IT_STATS is data structure containing statistics on model at each
%iteration (no. agents etc)
%ENV_DATA is a data structure containing information about the model
%environment
%    ENV_DATA.shape - shape of environment - FIXED AS SQUARE
%    ENV_DATA.units - FIXED AS KM
%    ENV_DATA.bm_size - length of environment edge in km
%    ENV_DATA.food is  a bm_size x bm_size array containing distribution
%    of food
     
 
spd=agt.speed;   % Macrophage migration speed in units per iteration - this is equal to the food searching radius
pos=agt.pos;     % Extract current position 

upper=ENV_DATA.bm_size-PARAM.F_RADIUS;   % The upper limit in each axis that the macrophage can migrate
lower=PARAM.F_RADIUS;   % The lower limit in each axis that the macrophage can migrate


typ=MESSAGES.atype;                     % Extract types of all agents
macro=find(typ==2);                     % Indices of all macrophages
mpos=MESSAGES.pos(macro,:);             % Extract positions of all macrophages
dist2=zeros(1,length(macro));           % Create an array to store the distance between this and all other macrophages

mig=0;                        % Flag to tell that this macrophage not moved yet.
cnt=1;                        % Initialise the counter.
theta=rand*2*pi;              % Macrophage has been unable to find food, so chooses a random direction to move in
phi=rand*pi;
        
while mig==0&cnt<=8        % Macrophage has up to 8 attempts to migrate (without leaving the edge of the model)
    npos(1)=pos(1)+spd*cos(theta)*sin(phi);        % New x co-ordinate
    npos(2)=pos(2)+spd*sin(theta)*sin(phi);        % New y co-ordinate
    npos(3)=pos(3)+spd*cos(phi);
    if npos(1)<upper&npos(2)<upper&npos(3)<upper&npos(1)>lower&npos(2)>lower&npos(3)>lower   % Check that macrophage has not left edge of model - correct if so.
        
        % The following chunk of code checks and makes sure the macrophage will
        % not run into other macrophage
        for i=1:length(macro)
            if macro(i)==cn         % Exclude itself in the list
                dist2(1,i)=999.;    % Setting the self-distance to a fairly large value
                continue
            end
            dist2(1,i)=(mpos(i,1)-npos(1)).^2+(mpos(i,2)-npos(2)).^2+(mpos(i,3)-npos(3)).^2;  % Calculate distance (square) to all other macrophage
        end

        if min(dist2)>(PARAM.COLLISION.^2)   % Make sure that the E.coli will NOT run into any macrophage  
            mig=1;                             % Flag to tell that this macrophage has already moved.
        end
    end
    cnt=cnt+1;                  % Increase the counter by 1.
    theta=theta+(pi/4);         % If migration not successful, then increment direction by 45 degrees and try again
    phi=phi+(pi/8);             % If migration not successful, then increment direction by 45 degrees and try again
end

if mig==1
    agt.pos=npos;                    % Update agent memory
    MESSAGES.pos(cn,:)=agt.pos;      % Update the message (position)
    IT_STATS.mig(N_IT+1)=IT_STATS.mig(N_IT+1)+1;    % Update model statistics
end


    
   
