function [agt,klld]=die(agt,cn)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

%Death function for class macrophage
%agt=macrophage object
%cn - current agent number
%klld=1 if agent dies, =0 otherwise

% Macrophage die if their food level reaches zero or they are older than max_age

global PARAM IT_STATS N_IT MESSAGES

%N_IT is current iteration number
%IT_STATS is data structure containing statistics on model at each
%iteration (no. agents etc)
%PARAM is data structure containing migration speed and breeding
%frequency parameters for both macrophage and E.coli
%MESSAGES is a data structure containing information that agents need to
%broadcast to each other
%    MESSAGES.atype - n x 1 array listing the type of each agent in the model
%    (1=rabbit, 2-macrophage, 3=dead agent)
%    MESSAGES.pos - list of every agent position in [x y]
%    MESSAGE.dead - n x1 array containing ones for agents that have died
%    in the current iteration
   
klld=0;
thold=PARAM.F_MINFOOD;      % Threshold minimum food value for death to occur
cfood=agt.food;             % Get current agent food level
age=agt.age;                % Get current agent age

if cfood<=thold|age>PARAM.F_MAXAGE      % If food level < threshold and age > max age then agent dies
    IT_STATS.died_f(N_IT+1)=IT_STATS.died_f(N_IT+1)+1;  % Update statistics
    MESSAGES.dead(cn)=1;                % Update message list
    klld=1;
end