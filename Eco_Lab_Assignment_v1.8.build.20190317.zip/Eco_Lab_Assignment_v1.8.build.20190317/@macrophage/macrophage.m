classdef macrophage           % Declares macrophage object
    properties                % Define macrophage properties (parameters) 
        age; 
        food;
        pos;
        speed;
        last_breed;
    end
    methods                         % Note that this class definition mfile contains only the constructor method!
                                    % All additional member functions associated with this class are included as separate mfiles in the @macrophage folder. 
        function f=macrophage(varargin) % Constructor method for macrophage  - assigns values to macrophage properties
                %f=macrophage(age,food,pos....)
                %
                %age of agent (usually 0)
                %food - amount of food that rabbit has eaten
                %pos - vector containg x,y, co-ords 

                %Modified by Martin Bayley on 29/01/13

            switch nargin                     % Use switch statement with nargin,varargin contructs to overload constructor methods
                case 0                        % Create default object
                    f.age=[];			
                    f.food=[];
                    f.pos=[];
                    f.speed=[];
                    f.last_breed=[];
                case 1                         % Input is already a macrophage, so just return!
                    if (isa(varargin{1},'macrophage'))		
                        f=varargin{1};
                    else
                        error('Input argument is not a macrophage')
                    end
                case 5                               % Create a new macrophage (currently the only constructor method used)
                    f.age=varargin{1};               % Age of macrophage object in number of iterations
                    f.food=varargin{2};              % Current food content (arbitrary units)
                    f.pos=varargin{3};               % Current position in Cartesian co-ords [x y]
                    f.speed=varargin{4};             % Number of micrometres macrophage can migrate in 1 day
                    f.last_breed=varargin{5};        % Number of iterations since macrophage last reproduced.
                otherwise
                    error('Invalid no. of input arguments for macrophage')
            end
        end
    end
end