function val=get(c,prop_name)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

% Standard function to allow extraction of memory parameters from macrophage
% objects.

switch prop_name
   
case 'age'
   val=c.age;
case 'food'
   val=c.food;
case 'pos'
    val=c.pos;
case 'speed'
     val=c.speed;
case 'last_breed'
     val=c.last_breed;  
otherwise 
   error('invalid field name')
end

