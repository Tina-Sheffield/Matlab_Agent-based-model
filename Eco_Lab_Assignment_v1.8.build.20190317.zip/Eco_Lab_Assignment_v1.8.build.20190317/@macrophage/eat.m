function [agt,eaten]=eat(agt,cn)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

%Eating function for class macrophage
%agt=macrophage object
%cn - current agent number
%eaten = 1 if macrophage successfully finds a E.coli, eaten=0 otherwise

%GLOBAL VARIABLES
%N_IT is current iteration number
%IT_STATS is data structure containing statistics on model at each
%iteration (no. agents etc)
%MESSAGES is a data structure containing information that agents need to
%broadcast to each other
%    MESSAGES.atype - n x 1 array listing the type of each agent in the model
%    (1=E.colli, 2-macrophage, 3=dead agent)
%    MESSAGES.pos - list of every agent position in [x y]
%    MESSAGE.dead - n x1 array containing ones for agents that have died
%    in the current iteration
   


global  IT_STATS N_IT MESSAGES ENV_DATA PARAM
   
pos=agt.pos;                        % Extract current position 
cfood=agt.food;                     % Get current agent food level
spd=agt.speed;                      % Macrophage migration speed in units per iteration - this is equal to the food searching radius
spd2=spd^2;                       % To improve efficiency, calculated as the square of the speed
eaten=0;

typ=MESSAGES.atype;                 % Extract types of all agents
rb=find(typ==1);                    % Indices of all E.coli
macro=find(typ==2);                 % Indices of all macrophage
rpos=MESSAGES.pos(rb,:);            % Extract positions of all E.coli
mpos=MESSAGES.pos(macro,:);         % Extract positions of all macrophage

csep2=(rpos(:,1)-pos(1)).^2+(rpos(:,2)-pos(2)).^2+(rpos(:,3)-pos(3)).^2;  % Calculate distance to all E.coli
dist2=zeros(1,length(macro));       % Create an array to store the distance between this and all other macrophages


[ncsep2,ind]=sort(csep2);           % ind is index of that E.coli that within food searching radius
[~,indx]=find(ncsep2<=(PARAM.F_SRCH^2));        % Index of E.coli within the food searching radius
nrst=rb(ind(indx));                 % Index of E.coli within the food searching radius (sorted in asceding order)          


% Determine the rules of macrophage eating nutrient. 
if ENV_DATA.food>=PARAM.F_EATRATE                     % If food available in environment 
    ENV_DATA.food=ENV_DATA.food-PARAM.F_EATRATE;      % Reduce environment food by 64 unit
    agt.food=cfood+PARAM.F_EATRATE;                   % Increase agent food by 64 unit



    cnt=0;
    while ~isempty(nrst) & eaten==0 & cnt<50  % If there is E.coli in adjacent colonys within the search radius  
        cnt=cnt+1;
        if cnt>length(nrst)
            break
        end
        s=nrst(cnt);  % Pick one of the nearest E.coli
    
        nx=MESSAGES.pos(s,1);    % Extract exact location of this E.coli
        ny=MESSAGES.pos(s,2);
        nz=MESSAGES.pos(s,3); 
        
        
        cdist2=(nx-pos(1)).^2+(ny-pos(2)).^2+(nz-pos(3)).^2;  % Calculate squared distance to this (picked) E.coli
        if cdist2>spd2   % If the distance between E.coli and the macrophage is larger than macrophage's speed
            cdist=sqrt(cdist2);  % Calculate distance to this (picked) E.coli
            nx=pos(1)+spd/cdist*(nx-pos(1));   % The macrophage will move towards that direction at the maximum speed.
            ny=pos(2)+spd/cdist*(ny-pos(2));   % The macrophage will move towards that direction at the maximum speed.
            nz=pos(3)+spd/cdist*(nz-pos(3));   % The macrophage will move towards that direction at the maximum speed.
        end
    
        % The following code make sure macrophage is always within the Petri
        % dish (based on the collision size of a macrophage).
        if nx-PARAM.COLLISION<0
            nx=PARAM.COLLISION;
        end
        if ny-PARAM.COLLISION<0
            ny=PARAM.COLLISION;
        end
        if nz-PARAM.COLLISION<0
            nz=PARAM.COLLISION;
        end
        if nx+5>ENV_DATA.bm_size
            nx=ENV_DATA.bm_size-PARAM.COLLISION;
        end
        if ny+5>ENV_DATA.bm_size
            ny=ENV_DATA.bm_size-PARAM.COLLISION;
        end
        if nz+5>ENV_DATA.bm_size
            nz=ENV_DATA.bm_size-PARAM.COLLISION;
        end
    
        % The following chunk of code checks and makes sure the macrophage will
        % not run into other macrophage
        for i=1:length(macro)
            if macro(i)==cn     % Exclude itself in the list
                dist2(1,i)=9999.;   % Setting the self-distance to a fairly large value
                continue
            end
            dist2(1,i)=(mpos(i,1)-nx).^2+(mpos(i,2)-ny).^2+(mpos(i,3)-nz).^2;  % Calculate distance (square) to all other macrophage
        end
            
        if min(dist2)>=(PARAM.COLLISION.^2)   % Make sure that the E.coli will NOT run into any macrophage    
            agt.pos=[nx ny nz];               % Move agent to position of the new position
            ncsep2=(rpos(:,1)-nx).^2+(rpos(:,2)-ny).^2+(rpos(:,3)-nz).^2;   % Calculate the distance between all E.coli and the macrophage
            deadlist_index=find(ncsep2<=(PARAM.F_RADIUS^2));    % Create the list of E.coli indexes that will be eaten by macrophage
            deadlist=rb(deadlist_index);    % The corresponding list of E.coli indexes that will be eaten by macrophage
    
            for i=1:length(deadlist)  % Loop over the index of all E.coli that will be phagocytosed.
               % agt.food=cfood+1;           %increase agent food by one unit
                col_index=ceil(MESSAGES.pos(deadlist(i),:)/5);
                MESSAGES.colony(col_index(1),col_index(2),col_index(3))=MESSAGES.colony(col_index(1),col_index(2),col_index(3))-1;      % Update the number of E.coli within a local colony if we find a E.coli was eaten
                MESSAGES.dead(deadlist(i))=1;  %Send message to these E.coli as dead.
                MESSAGES.pos(deadlist(i),:)=[-1 -1 -1];     % Enter dummy position in list
                MESSAGES.atype(deadlist(i))=0;              % Set type to dead
                IT_STATS.eaten(N_IT+1)=IT_STATS.eaten(N_IT+1)+1;    % Update model statistics
            end
        
            MESSAGES.pos(cn,:)=agt.pos;   % Update the message (position)
            eaten=1;
            break    % Break the current for loop
        end
    end

else
    agt.food=cfood-PARAM.F_EATRATE/4;                   % Decrease agent food by 16 unit
    eaten = 1;                          % Flag tells E.coli NOT to migrate

end

   
