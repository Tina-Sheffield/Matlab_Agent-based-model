function [agt,new]=breed(agt,cn)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19


% Breeding function for class macrophage
%agt = macrophage object
%cn = current agent number
%new = contains new  agent object if created, otherwise empty

global PARAM IT_STATS N_IT
%N_IT is current iteration number
%IT_STATS is data structure containing statistics on model at each
%iteration (no. agents etc)
%PARAM is data structure containing migration speed and breeding
%frequency parameters for both macrophage and E.coli

   
flim=PARAM.F_FOODBRD;       % Minimum food level required for breeding
tlim=PARAM.F_BRDFQ;         % Minimum interval required for breeding
cfood=agt.food;             % Get current agent food level
age=agt.age;                % Get current agent age
last_breed=agt.last_breed;  % Length of time since agent last reproduced
pos=agt.pos;                % Current position

if cfood>=flim && last_breed>=tlim                % If food > threshold and age > interval, then create offspring
   new=macrophage(0,cfood/2,pos,PARAM.F_SPD,0);   % New macrophage agent
   agt.food=cfood/2;                              % Divide food level between 2 agents
   agt.last_breed=0;                              % Calculate the time after last breed (0)
   agt.age=age+1;                                 % Increase age by 1
   IT_STATS.div_f(N_IT+1)=IT_STATS.div_f(N_IT+1)+1;% Update statistics
else                            
    agt.age=age+1;                                % Not able to breed, so increment age by 1
    agt.last_breed=last_breed+1;                  % Increase time interval after last breed by 1.
    new=[];                                       % No baby macrophage is born
end