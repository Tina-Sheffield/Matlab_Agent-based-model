function ecolab(size,food,nr,nf,nsteps,fmode,outImages)

%ECO_LAB  agent-based predator-prey-competitor model

%AUTHOR Dawn Walker d.c.walker@sheffield.ac.uk
%Created April 2008
%Modified by Tiantian Xian & Yiting Zheng
%Modified March 2019


%ecolab(size,food nr,nf,nsteps)
%size = size of model environmnet in km (sugested value for plotting 
%purposes =200)
%food - initial food in Petri dish (suggested value: arround 10000)
%nr - initial number of E.coli agents
%nf - initial number of macrophage agents
%nsteps - number of iterations required

%definition of global variables:
%N_IT - current iteration number
%IT_STATS  -  is data structure containing statistics on model at each
%iteration (number of agents etc). iniitialised in initialise_results.m
%ENV_DATA - data structure representing the environment (initialised in
%create_environment.m)
%CONTROL_DATA - control parameters that plot the graphs
%PARAM - structure containing values of all parameters governing agent
%behaviour for the current simulation


    
    %clear any global variables/ close figures from previous simulations
    clear global
    close all

    global N_IT IT_STATS ENV_DATA CONTROL_DATA PARAM
    
%% Define the model for computational.
    if nargin == 5
        fmode=true;
        outImages=false;
    elseif nargin == 6
        outImages=false;
    end
    
%% MODEL INITIALISATION
    create_control;                     %sets up the parameters to control fmode (speed up the code during experimental testing
    create_params;                      %sets the parameters for this simulation
    create_environment(size,food);      %creates environment data structure, given an environment size
    random_selection(1);                %randomises random number sequence (NOT agent order). If input=0, then simulation should be identical to previous for same initial values
    [agent]=create_agents(nr,nf);       %create nr E.coli and nf macrophage agents and places them in a cell array called 'agents'
    create_messages(size,nr,nf,agent);  %sets up the initial message lists
    initialise_results(nr,nf,nsteps);   %initilaises structure for storing results
    
%% MODEL EXECUTION
    for n_it=1:nsteps                   % The main execution loop
        N_IT=n_it;                      % Current number of iteration
        [agent,n]=agnt_solve(agent);     % The function which calls the rules
        
        if ~mod(n_it,PARAM.FEED_INTERVAL)   % Determine whether to add food to Petri dish in the current iteration
            ENV_DATA.food=ENV_DATA.food+food;  % Add food to the Petri dish every 2 hours
        end
        IT_STATS.tfood(N_IT+1)=ENV_DATA.food;   % Total food remaining
        
        plot_results(agent,nsteps,fmode,outImages); % Updates results figures and structures
        %mov(n_it)=getframe(fig3);
        if n<=0                          %If no more agents, then stop simulation
            break
            disp('General convergence criteria satisfied - no agents left alive! > ')
        end
        if fmode == true                                       % If fastmode is used ...
           for test_l=1 : 5                                    % This checks the total number agents and adjusts the CONTROL_DATA.fmode_display_every variable accoringly to help prevent extreme slowdown
               if n > CONTROL_DATA.fmode_control(1,test_l)     % CONTROL_DATA.fmode_control contains an array of thresholds for agent numbers and associated fmode_display_every values
                   CONTROL_DATA.fmode_display_every = CONTROL_DATA.fmode_control(2,test_l);
               end
           end
            if IT_STATS.tot_r(n_it) == 0             % Fastmode convergence - all E.coli eaten - all macrophages will now die
                disp('Fast mode convergence criteria satisfied - no E.coli left alive! > ')
                break
            end  
            if IT_STATS.tot_f(n_it) == 0             % Fastmode convergence - all macrophages starved - E.coli will now proliferate unchecked until all nutrien is eaten
                disp('Fast mode convergence criteria satisfied - no macrophage left alive ! > ')
                break
            end
        end
    end
eval(['save results_nr_' num2str(nr) '_nf_' num2str(nf) '.mat IT_STATS ENV_DATA' ]);
clear global


 
