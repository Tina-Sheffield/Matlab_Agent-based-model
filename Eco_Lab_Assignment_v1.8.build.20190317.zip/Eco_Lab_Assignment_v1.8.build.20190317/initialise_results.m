function initialise_results(nr,nf,nsteps)

 global  IT_STATS ENV_DATA 
 
%set up data structure to record statistics for each model iteration
%IT_STATS  -  is data structure containing statistics on model at each
%iteration (number of agents etc)
%ENV_DATA - data structure representing the environment 
   
   
%Modified by Tiantian Xian & Yiting Zheng
%Modified March 2019

%%
 IT_STATS=struct('div_r',[zeros(1,nsteps+1);],...            %no. newly norn E.coli per iteration
                'div_f',[zeros(1,nsteps+1)],...             %no. newly norn macrophage per iteration (should be zero as macrophage does not breed)
                'died_r',[zeros(1,nsteps+1)],...			%no. E.coli dying per iteration
                'died_f',[zeros(1,nsteps+1)],...		    %no. macrophage dying per iteration
                'eaten',[zeros(1,nsteps+1)],...              %no. E.coli eaten per iteration
                'mig',[zeros(1,nsteps+1)],...                %no. agents migrating per iteration
                'tot',[zeros(1,nsteps+1)],...				%total no. agents in model per iteration
                'tot_r',[zeros(1,nsteps+1)],...             % total no. E.coli
                'tot_f',[zeros(1,nsteps+1)],...             % total no. macrophage
                'tfood',[zeros(1,nsteps+1)]);               %remaining food level in environment
            

 IT_STATS.tot(1)=nr+nf;    %total number of agents
 IT_STATS.tot_r(1)=nr;    %total number of E.coli
 IT_STATS.tot_f(1)=nf;    %total number of macrophage
 IT_STATS.tfood(1)=ENV_DATA.food;   %remaining food in environment
