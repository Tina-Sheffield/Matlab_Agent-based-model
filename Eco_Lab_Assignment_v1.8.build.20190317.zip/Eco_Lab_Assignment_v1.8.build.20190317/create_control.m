function create_control ()
%Data to enable fast mode and to allow pausing during opperation to zoom
%and pan on the current plotted figure

%CONTROL_DATA - control parameters that plot the graphs


%Modified by Tiantian Xian & Yiting Zheng
%Modified March 2019

%%
global CONTROL_DATA

CONTROL_DATA.fmode_display_every = 1;
CONTROL_DATA.fmode_control =[500 1000 2000 4000 8000 ; 1 1 1 2 4];
CONTROL_DATA.pause = false;

end

