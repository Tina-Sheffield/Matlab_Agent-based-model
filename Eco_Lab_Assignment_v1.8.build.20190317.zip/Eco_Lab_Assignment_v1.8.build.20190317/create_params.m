function create_params

%set up breeding, migration and starvation threshold parameters. These
%are all completely made up!

%PARAM - structure containing values of all parameters governing agent
%behaviour for the current simulation
   
   
%Modified by Tiantian Xian & Yiting Zheng
%Modified March 2019

%%
global PARAM

    PARAM.R_SPD=5;         %speed of movement - units per itn (E.coli)
    PARAM.F_SPD=40;         %speed of movement - units per itn (macrophage)
    PARAM.F_SRCH=120;       %food searching (detection) radius (macrophage)
     
    PARAM.R_BRDFQ=1;      %breeding frequency - iterations (E.coli)
    PARAM.F_BRDFQ=10000;  %breeding frequency - iterations (macrophage)
    
    PARAM.R_MINFOOD=0;      %minimum food threshold before agent dies (E.coli) 
    PARAM.F_MINFOOD=0;      %minimum food threshold before agent dies (macrophage)
    
    PARAM.R_FOODBRD=4;     %minimum food threshold for breeding (E.coli)
    PARAM.F_FOODBRD=100000; %minimum food threshold for breeding(macrophage)
    
    PARAM.R_MAXAGE=6;      %maximum age allowed (E.coli) 
    PARAM.F_MAXAGE=1512;   %maximum age allowed (macrophage)
    
    PARAM.R_BR_RADIUS=5;   %The radius of a new born E.coli around the mother E.coli
    PARAM.COL_THRESHOLD=25;     %The threshold number of E.coli within a local colony
    PARAM.COL_MAX=125;     %The maximum number of E.coli within a local colony
    
    PARAM.F_RADIUS=5;     %The radius (size/2) of a macrophage
    PARAM.COLLISION=PARAM.F_RADIUS/(sqrt(2));    %The collision radius of a macrophage (between macrophage)
    
    PARAM.FEED_INTERVAL=6;       %The time interval to add food into the Petri dish
    
    PARAM.R_EATRATE = 1;    % Eating rate (E.coli)
    PARAM.F_EATRATE = 64;   % Eating rate (macrophage)
