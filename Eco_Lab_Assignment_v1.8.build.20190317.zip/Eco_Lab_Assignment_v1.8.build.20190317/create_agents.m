function [agent]=create_agents(nr,nf)

 %creates the objects representing each agent
 
%agent - cell array containing list of objects representing agents
%nr - number of rabbits
%nf - number of foxes

%global parameters
%ENV_DATA - data structure representing the environment (initialised in
%create_environment.m)
%MESSAGES is a data structure containing information that agents need to
%broadcast to each other
%PARAM - structure containing values of all parameters governing agent
%behaviour for the current simulation


%Modified by Tiantian Xian & Yiting Zheng
%Modified March 2019


%% 
global ENV_DATA MESSAGES PARAM 
  
bm_size=ENV_DATA.bm_size;
rloc=(bm_size-1)*rand(nr,3)+1;      %generate random initial positions for rabbits
floc=(bm_size-1)*rand(nf,3)+1;      %generate random initial positions for foxes

MESSAGES.pos=[rloc;floc];

%generate all rabbit agents and record their positions in ENV_MAT_R
for r=1:nr
    pos=rloc(r,:);
    %create E.coli agents with random ages between 0 and 1 hours and random
    %food levels 3-4
    age=ceil(rand*3);
    food=ceil(rand*2)+2;
    lbreed=round(rand*PARAM.R_BRDFQ);
    agent{r}=E_coli(age,food,pos,PARAM.R_SPD,lbreed);
end

%generate all fox agents and record their positions in ENV_MAT_F
for f=nr+1:nr+nf
    pos=floc(f-nr,:);
    %create macrophage agents with random ages between 0 and 7 days and random
    %food levels 200-300
    age=ceil(rand*504);
    food=ceil(rand*100)+200;
    lbreed=round(rand*PARAM.F_BRDFQ);
    agent{f}=macrophage(age,food,pos,PARAM.F_SPD,lbreed);
end
