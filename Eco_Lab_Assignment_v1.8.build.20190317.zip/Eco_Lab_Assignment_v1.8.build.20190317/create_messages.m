function create_messages(size,nr,nf,agent)

%function that populates the global data structure representing
%message information

%MESSAGES is a data structure containing information that agents need to
%broadcast to each other
   %    MESSAGES.atype - n x 1 array listing the type of each agent in the model
   %    (1=E.coli, 2=macrophage, 3=dead agent)
   %    MESSAGES.pos - list of every agent position in [x y z]
   %    MESSAGE.dead - n x 1 array containing ones for agents that have died
   %    in the current iteration
   
   
%Modified by Tiantian Xian & Yiting Zheng
%Modified March 2019

%%
global MESSAGES
 
MESSAGES.colony_size = ceil(size/5);    %The mesh size (5*5*5) of a local colony of E.coli
MESSAGES.colony=zeros(MESSAGES.colony_size,MESSAGES.colony_size,MESSAGES.colony_size);     %Initialise the number of E.coli within a local colony

 for an=1:length(agent)
     if isa(agent{an},'E_coli')
        MESSAGES.atype(an)=1;
        MESSAGES.pos(an,:)=get(agent{an},'pos');    %Get the position of current agent
        cpos=ceil(MESSAGES.pos(an,:)/5);         %Determine which local colony the current E.coli belongs to
        MESSAGES.colony(cpos(1),cpos(2),cpos(3))=MESSAGES.colony(cpos(1),cpos(2),cpos(3))+1;      %update the number of E.coli within a local colony if we find a E.coli is within it
     elseif isa(agent{an},'macrophage')
        MESSAGES.atype(an)=2;
        MESSAGES.pos(an,:)=get(agent{an},'pos');    %Get the position of current agent
     else
        MESSAGES.atype(an)=0; 
        MESSAGES.pos(an,:)=[-1 -1 -1];
     end
     MESSAGES.dead(an)=0;
 end
     
