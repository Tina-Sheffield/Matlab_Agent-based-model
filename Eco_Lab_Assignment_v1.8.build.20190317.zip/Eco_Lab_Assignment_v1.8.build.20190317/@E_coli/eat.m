function [agt,eaten]=eat(agt,cn)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

%SUMMARY OF E.coli EAT RULE
%================================
% E.coli detects nutrition, namely the total number of food, in the environment.
% If the total amount of food (in unit) is larger than 1, then E.coli 
% consume 1 unit of food, agent�s food level increase 1 unit.
% If there is no food in the environment, the agent�s food level will 
% decrease 1 unit.
% We assume that nutrition is homogenously distributed in the Petri dish 
% that E.coli does not need to move to find food.
%================================

% Eating function for class E.coli
%agt = E.coli object
%cn = current agent number
%eaten = 1 if E.coli finds food, eaten =0 otherwise

%ENV_DATA is a data structure containing information about the model environment
   %    ENV_DATA.shape - shape of environment - FIXED AS SQUARE
   %    ENV_DATA.units - FIXED AS mm
   %    ENV_DATA.bm_size - length of environment edge in mm
   %    ENV_DATA.food is  a bm_size x bm_size array containing distribution of food
  



global  ENV_DATA MESSAGES PARAM

pos=agt.pos;                            % Extract current position 
cfood=agt.food;                         % Get current agent food level

if ENV_DATA.food>=PARAM.R_EATRATE                     % If food available in environment 
    ENV_DATA.food=ENV_DATA.food-PARAM.R_EATRATE;      % Reduce environment food by one unit
    agt.food=cfood+PARAM.R_EATRATE;                   % Increase agent food by one unit
    eaten=1;                                          % E.coli has eaten - set flag to tell E.coli NOT to migrate
else
    agt.food=cfood-PARAM.R_EATRATE;                   % Decrease agent food by one unit
    eaten=1;                                          % Flag tells E.coli NOT to migrate
end

cpos=ceil(pos/5);         % Determine which local colony the current E.coli belongs to
colony_pop=MESSAGES.colony(cpos(1),cpos(2),cpos(3));  % Get the number of E.coli in the current local colony

if colony_pop>=PARAM.COL_THRESHOLD  % If the number of E.coli in the current local colony is larger than the threshold
    eaten=0;                                          % Flag tells E.coli to migrate
end

    
   
