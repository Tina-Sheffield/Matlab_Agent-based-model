function [agt]=migrate(agt,cn)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

%SUMMARY OF E.coli Migrate RULE
%================================

%================================

% Migration functions for class E.coli
%agt = E.coli object
%cn = current agent number


global ENV_DATA IT_STATS N_IT MESSAGES PARAM
%N_IT is current iteration number
%IT_STATS is data structure containing statistics on model at each
%iteration (no. agents etc)
%interpolated to each grid point
%ENV_DATA is a data structure containing information about the model
%environment.
%    ENV_DATA.shape - shape of environment - FIXED AS SQUARE
%    ENV_DATA.units - FIXED AS mm
%    ENV_DATA.bm_size - length of environment edge in mm
%    ENV_DATA.food is  a bm_size x bm_size array containing distribution
%    of food

mig=0;                               % Indicates whether E.coli has successfully migrated
pos=agt.pos;                         % Extract current position 
cpos=ceil(pos/5);                    % Determine which local colony the current E.coli belongs to
spd=agt.speed;                       % E.coli migration speed in units per iteration - this is equal to the food search radius
spd2=spd^2;
boundary=ENV_DATA.bm_size;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function searches for the colony, which has the smallest number of
% E.coli, adjacent to the current colony (the current E.coli belongs to).
[x_indx,y_indx,z_indx]=target_colony(cpos);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

typ=MESSAGES.atype;                   % Extract types of all agents
marco=typ==2;                         % Indices of all macrophage
mpos=MESSAGES.pos(marco,:);           % Extract positions of all macrophage

mig=0;                                % Flag will be reset to one if E.coli migrates
cnt=0;                                % Set up a counter
while mig==0 && cnt<25                % Try 25 times to find a random position in the new colony (for the E.coli to move)
    cnt=cnt+1;
    xa=(x_indx-rand)*5;               % x co-ordiantes of new position of the current E.coli
    ya=(y_indx-rand)*5;               % y co-ordiantes of new position of the current E.coli
    za=(z_indx-rand)*5;               % z co-ordiantes of new position of the current E.coli
    csep2=(xa-pos(1)).^2+(ya-pos(2)).^2+(za-pos(3)).^2;   % Calculate the distance (square) between the new position and current position
    
    if csep2<=spd2       % If the distance (square) is smaller than the speed (square) of E.coli
        if xa<boundary && ya<boundary && za<boundary && xa>0 && ya>0 && za>0   % Check that E.coli has not left edge of Petri dish
            dist2=(mpos(:,1)-xa).^2+(mpos(:,2)-ya).^2+(mpos(:,3)-za).^2;  % Calculate distance to all macrophage
            if min(dist2)>(PARAM.F_RADIUS^2)   % Make sure that the E.coli will NOT run into any macrophage
                npos=[xa ya za];
                mig=1;
            end
        end
    end
end

% If the random move fails, E.coli will try move directly (in a fixes angle) to the new colony
cnt=0;          % Set up a counter
while mig==0 && cnt<10      % Try 10 times                      
    scale_factor=(10-cnt)/10;      % Gradually reduce the speed of the E.coli in each try
    xa=(xa-cpos(1))*spd*scale_factor;        % New x co-ordinate
    ya=(ya-cpos(2))*spd*scale_factor;        % New y co-ordinate
    za=(za-cpos(3))*spd*scale_factor;        % New z co-ordinate
    if xa<boundary && ya<boundary && za<boundary && xa>0 && ya>0 && za>0   % Check that E.coli has not left edge of Petri dish
        dist2=(mpos(:,1)-xa).^2+(mpos(:,2)-ya).^2+(mpos(:,3)-za).^2;  % Calculate distance to all macrophage
        if min(dist2)>(PARAM.F_RADIUS^2)   % Make sure that the E.coli will NOT run into any macrophage
            npos=[xa ya za];
            mig=1;
        end
    end
    cnt=cnt+1;
end


if mig==1
    col_index=ceil(agt.pos/5);
    MESSAGES.colony(col_index(1),col_index(2),col_index(3))=MESSAGES.colony(col_index(1),col_index(2),col_index(3))-1;      % Update the number of E.coli within a local colony
    agt.pos=npos;                     % Update agent memory
    MESSAGES.pos(cn,:)=agt.pos;       % Update the message (position)
    ncol_index=ceil(agt.pos/5);
    MESSAGES.colony(ncol_index(1),ncol_index(2),ncol_index(3))=MESSAGES.colony(ncol_index(1),ncol_index(2),ncol_index(3))+1;      % Update the number of E.coli within a local colony if we find a E.coli is within it
    IT_STATS.mig(N_IT+1)=IT_STATS.mig(N_IT+1)+1;    % Update model statistics
end
