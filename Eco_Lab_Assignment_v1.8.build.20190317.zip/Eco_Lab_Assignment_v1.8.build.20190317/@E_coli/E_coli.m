classdef E_coli   % Declares E.coli object
    
% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

    properties    % Define E.coli properties (parameters) 
        age; 
        food;
        pos;
        speed;
        last_breed;
    end
    methods                         % Note that this class definition script contains only the constructor method!
                                    % All additional member functions associated with this class are included as separate script in the @E.coli folder. 
        function r=E_coli(varargin) % Constructor method for E.coli - assigns values to E.coli properties
                % r=E_coli(age,food,pos....)
                %
                % age = agent's age
                % food = amount of food that E.coli has eaten
                % pos = vector containg x,y, co-ords 

                


                switch nargin           % Use switch statement with nargin,varargin contructs to overload constructor methods
                    case 0				% Create default object
                       r.age=[];			
                       r.food=[];
                       r.pos=[];
                       r.speed=[];
                       r.last_breed=[];
                    case 1              % Input is already a E.coli, so just return!
                       if (isa(varargin{1},'E_coli'))		
                            r=varargin{1};
                       else
                            error('Input argument is not a E.coli')
                            
                       end
                    case 5               % create a new E.coli (currently the only constructor method used)
                       r.age=varargin{1};               % Age of E.coli object in number of iterations
                       r.food=varargin{2};              % Current food content (arbitrary units)
                       r.pos=varargin{3};               % Current position in Cartesian co-ords [x y]
                       r.speed=varargin{4};             % Number of kilometres E.coli can migrate in 1 day
                       r.last_breed=varargin{5};        % Number of iterations since E.coli last reproduced.
                    otherwise
                       error('Invalid no. of input arguments')
                end
        end
    end
end
