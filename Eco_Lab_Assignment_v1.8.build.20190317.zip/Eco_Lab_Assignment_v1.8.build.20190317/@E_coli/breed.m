function [agt, new]=breed(agt,cn)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

% Breeding function for class E.coli
%agt = E_coli object
%cn = current agent number
%new = contains new  agent object if created, otherwise empty

global PARAM IT_STATS N_IT MESSAGES ENV_DATA
%N_IT is current iteration number
%IT_STATS is data structure containing statistics on model at each
%iteration (no. agents etc)
%PARAM is data structure containing migration speed and breeding
%frequency parameters for both macrophage and E.coli
   
flim=PARAM.R_FOODBRD;       % Minimum food level required for breeding
tlim=PARAM.R_BRDFQ;         % Minimum interval required for breeding
cfood=agt.food;             % Get current agent food level
age=agt.age;                % Get current agent age
last_breed=agt.last_breed;  % Length of time since agent last reproduced
pos=agt.pos;                % Current position
boundary=ENV_DATA.bm_size;  % Get upper boundary of colony (the maximum index number of a colony in an axis)

typ=MESSAGES.atype;                                      % Extract types of all agents
marco=typ==2;                                            % Indices of all macrophage
mpos=MESSAGES.pos(marco,:);                              % Extract positions of all macrophage

will_breed=0;    % The flag to determine whether E.coli will breed or not based on the amount of food in Petri dish
typ=MESSAGES.atype;                                  % Extract types of all agents
rb=find(typ==1);                                     % Indices of all E.coli
breed_rate=(ENV_DATA.food/length(rb))/10;            % The possibility which E.coli will breed (for convenience, "breed_rate" could be larger than 1)
if breed_rate>rand
    will_breed=1;    % The E.coli will breed
end

col_index=ceil(pos/5);   % Determine the index of the colony it belongs to
if MESSAGES.colony(col_index(1),col_index(2),col_index(3))>=PARAM.COL_MAX  % If the current colony is too crowded
    will_breed=0;    % The E.coli will NOT breed
end
       
if cfood>=flim && last_breed>=tlim && will_breed==1  % If food > threshold and age > interval, then create offspring
   born=0;   % Flag to indicate the new E.coli has born
   cnt=0;
   while born==0 && cnt<27    % Try 3^3=27 times
       cnt=cnt+1;
       npos(1)=pos(1)+(rand-0.5)*PARAM.R_BR_RADIUS;      % Generate a random position in x axis aournd the current E.coli
       npos(2)=pos(2)+(rand-0.5)*PARAM.R_BR_RADIUS;      % Generate a random position in y axis aournd the current E.coli      
       npos(3)=pos(3)+(rand-0.5)*PARAM.R_BR_RADIUS;      % Generate a random position in z axis aournd the current E.coli     
       if npos(1)<boundary && npos(2)<boundary && npos(3)<boundary && npos(1)>0 && npos(2)>0 && npos(3)>0   % Check that E.coli has not left edge of Petri dish
           dist2=(mpos(:,1)-npos(:,1)).^2+(mpos(:,2)-npos(:,2)).^2+(mpos(:,3)-npos(:,3)).^2;  % Calculate distance to all macrophage
           if min(dist2)>(PARAM.F_RADIUS^2)   % Make sure that the E.coli will NOT run into any macrophage
               born=1;  % Flag to indicate the new E.coli will born
           end
       end
   end

   if born==1   % If the position of the new born meets the cretira (within the boundary & not run into macrophage)
       new=E_coli(0,cfood/2,npos,PARAM.R_SPD,0);   % New E.coli agent born at the random position generated
       col_index=ceil(npos/5); % Update the index of the colony that the baby E.coli belongs to.
       MESSAGES.colony(col_index(1),col_index(2),col_index(3))=MESSAGES.colony(col_index(1),col_index(2),col_index(3))+1;      % Update the number of E.coli within a local colony if we find a E.coli is within it
   
       agt.food=cfood/2;                     % Divide food level between 2 agents
       agt.last_breed=0;                     % Calculate the time after last breed.
       agt.age=age+1;                        % Calculate the age after this interation
       IT_STATS.div_r(N_IT+1)=IT_STATS.div_r(N_IT+1)+1;             % Update statistics
   else        % If the position of the new born does NOT meets the cretira (within the boundary & not run into macrophage)
       agt.age=age+1;                          % Not able to breed, so increment age by 1
       agt.last_breed=last_breed+1;            % Calculate the time after last breed.
       new=[];                                 % No new E.coli born
   end

else                            
    agt.age=age+1;                          % Not able to breed, so increment age by 1
    agt.last_breed=last_breed+1;            % Calculate the time after last breed.
    new=[];                                 % No new E.coli born
end
