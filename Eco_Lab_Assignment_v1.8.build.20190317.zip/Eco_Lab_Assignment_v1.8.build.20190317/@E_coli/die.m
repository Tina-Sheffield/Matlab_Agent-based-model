function [agt,klld]=die(agt,cn)

% Created by Martin Bayley on 29/01/13
% Modified by Tiantian Xian on 10/03/19

% Death function for class E.coli
%agt = E.coli object
%cn = current agent number
%klld = 1 if agent dies, kild =0 otherwise

%E.coli die if their food level reaches zero or they are older than max_age

global PARAM IT_STATS N_IT MESSAGES
%N_IT is current iteration number
%IT_STATS is data structure containing statistics on model at each
%iteration (no. agents etc)
%PARAM is data structure containing migration speed and breeding
%frequency parameters for both macrophages and E.coli
%MESSAGES is a data structure containing information that agents need to
%broadcast to each other
   %    MESSAGES.atype - n x 1 array listing the type of each agent in the model
   %    (1=E.coli, 2=macrophage, 3=dead agent)
   %    MESSAGES.pos - list of every agent position in [x y]
   %    MESSAGE.dead - n x1 array containing ones for agents that have died
   %    in the current iteration

klld=0;
thold=PARAM.R_MINFOOD;      % Threshold minimum food value for death to occur
cfood=agt.food;             % Get current agent food level
age=agt.age;                % Get current agent age

if cfood<=thold|age>PARAM.R_MAXAGE      % If food level < threshold or age > max age then agent dies
    pos=agt.pos;                        % Get current position
    col_index=ceil(pos/5);              % Get index of current colony
    MESSAGES.colony(col_index)=MESSAGES.colony(col_index)-1;      % Update the number of E.coli within a local colony if we find a E.coli is within it
    IT_STATS.died_r(N_IT+1)=IT_STATS.died_r(N_IT+1)+1;  % Update statistics
    MESSAGES.dead(cn)=1;                % Update message list
    klld=1;                             % Flag indicates that this E.coli will die.
end
