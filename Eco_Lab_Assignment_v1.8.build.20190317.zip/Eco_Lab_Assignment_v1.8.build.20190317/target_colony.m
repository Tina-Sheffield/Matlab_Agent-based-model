function [x_indx,y_indx,z_indx]=target_colony(cpos)

%Function to find the adjacent colony who has the lowest number of E.coli

%####################
%[x_indx,y_indx,z_indx]=target_colony(cpos)
%####################
    %x_index,y_indx,z_indx - the index of the colony which has the lowest
    %number of E.coli
    %cpos - the current colony index of the E.coli

%MESSAGES is a data structure containing information that agents need to
%broadcast to each other


%Created by Tiantian Xian
%Modified March 2019

%%
global MESSAGES


%Set the x,y,z coordinate of the target colony (the colony which the E.coli
%is moving to) to be the current colony
x_indx=cpos(1);
y_indx=cpos(2);
z_indx=cpos(3);

boundary=MESSAGES.colony_size;    %Get upper boundary of colony (the maximum index number of a colony in an axis)
colony_pop=MESSAGES.colony(cpos);    %Get the number of E.coli in the current colony

rand_num=randperm(6);    %Generate a vector of [1 2 3 4 5 6] and shauffle them.
for i=1:6
    switch rand_num(i)    %choose an adjacent colony based on the random number
        case 1
            adjacent_indx=[cpos(1)-1 cpos(2) cpos(3)];
        case 2
            adjacent_indx=[cpos(1) cpos(2)-1 cpos(3)];
        case 3
            adjacent_indx=[cpos(1) cpos(2) cpos(3)-1];
        case 4
            adjacent_indx=[cpos(1)+1 cpos(2) cpos(3)];
        case 5
            adjacent_indx=[cpos(1) cpos(2)+1 cpos(3)];
        case 6
            adjacent_indx=[cpos(1) cpos(2) cpos(3)+1];
    end
            
    %Make sure that the local colony we are choosing is within the boundary of the Petri dish
    if adjacent_indx(1)<1 || adjacent_indx(1)>boundary || adjacent_indx(2)<1 || adjacent_indx(2)>boundary || adjacent_indx(3)<1 || adjacent_indx(3)>boundary
        continue     %Skip to the next i
    end
    
    %Find the colony that has the smallest number of E.coli
    if MESSAGES.colony(adjacent_indx(1),adjacent_indx(2),adjacent_indx(3))<colony_pop
        x_indx=adjacent_indx(1);    %Get the x,y,z coordinate of the colony that that has the smallest number of E.coli
        y_indx=adjacent_indx(2);
        z_indx=adjacent_indx(3);
        colony_pop=MESSAGES.colony(x_indx,y_indx,z_indx);    %Update the number of E.coli so as to compare with the next colony
    end
end

