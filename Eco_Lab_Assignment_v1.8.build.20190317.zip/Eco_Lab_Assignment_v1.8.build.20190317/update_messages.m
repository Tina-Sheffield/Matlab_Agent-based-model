function [nagent,nn]=update_messages(agent,prev_n,temp_n)

%copy all surviving and new agents in to a new agent list - dead agents
%will be empty structures

%agent - list of existing agents, including those that have died in the
%current iteration
%prev_n - previous number of agents at the start of this iteration
%temp_n - number of existing agents, including those that have died in the
%current iteration
%nagent - list of surviving agents and empty structures
%nn - number of surviving agents

%global variables
%N_IT current iteration no
%IT_STATS data structure for saving model statistics
%MESSAGES is a data structure containing information that agents need to
%broadcast to each other
   %    MESSAGES.atype - n x 1 array listing the type of each agent in the model
   %    (1=E.coli, 2=macrophage, 3=dead agent)
   %    MESSAGES.pos - list of every agent position in [x y z]
   %    MESSAGE.dead - n x1 array containing ones for agents that have died
   %    in the current iteration
%ENV_DATA - is a data structure containing information about the model
   %environment

   
%Modified by Tiantian Xian & Yiting Zheng
%Modified March 2019

%%
global MESSAGES IT_STATS N_IT ENV_DATA PARAM

nagent=cell(1,temp_n);                  %initialise list for surviving agents
nn=0;                                   %tracks number of surviving agents
for cn=1:temp_n
    if isempty(agent{cn})               %agent died in a previous iteration (not the current one)
        dead=1;
    elseif cn<=prev_n                   %agent is not new, therefore it might have died
        dead=MESSAGES.dead(cn);         %will be one for agents that have died, zero otherwise
    else 
        if isa(agent{cn},'E_coli')   %If the newly born agent is an E.coli
	        typ=MESSAGES.atype;       %extract types of all agents
            marco=typ==2;          %indices of all macrophage
            mpos=MESSAGES.pos(marco,:);       %extract positions of all macrophage
	        cpos=get(agent{cn},'pos');     %Extract the position of this newly born E.coli
	        dist2=(mpos(:,1)-cpos(1)).^2+(mpos(:,2)-cpos(2)).^2+(mpos(:,3)-cpos(3)).^2;  %calculate distance to all macrophage
            dead=(min(dist2))<=(PARAM.F_RADIUS^2);   %Determine whether the newly born E.coli will die based on its distance to all macrophage
	        if dead==1
                col_index=ceil(cpos/5);
                MESSAGES.colony(col_index(1),col_index(2),col_index(3))=MESSAGES.colony(col_index(1),col_index(2),col_index(3))-1;      %update the number of E.coli within a local colony if we find a E.coli is within it
            end
        elseif isa(agent{cn},'macrophage')   %If the newly born agent is a macrophage
	        dead=0;   %It will definately NOT die as it is newly born
        end
    end
    
    if dead==0                          %if agent is not dead
        nagent{cn}=agent{cn};           %copy object into the new list
        pos=get(agent{cn},'pos');
        MESSAGES.pos(cn,:)=pos;                    
         if isa(agent{cn},'E_coli')
             MESSAGES.atype(cn)=1;
             IT_STATS.tot_r(N_IT+1)=IT_STATS.tot_r(N_IT+1)+1;
         elseif isa(agent{cn},'macrophage')
             MESSAGES.atype(cn)=2;
             IT_STATS.tot_f(N_IT+1)=IT_STATS.tot_f(N_IT+1)+1;
         end
         MESSAGES.dead(cn)=0;           %clear death message
         nn=nn+1;
    else                                %agent has died
        MESSAGES.pos(cn,:)=[-1 -1 -1];     %enter dummy position in list
        MESSAGES.atype(cn)=0;           %set type to dead
        MESSAGES.dead(cn)=0;            %clear death message
    end
end
IT_STATS.tot(N_IT+1)=nn;                %update total agent number
IT_STATS.tfood(N_IT+1)=ENV_DATA.food;   %total food remaining
