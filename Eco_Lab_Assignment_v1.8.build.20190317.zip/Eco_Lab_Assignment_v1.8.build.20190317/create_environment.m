function create_environment(size,food)

%function that populates the global data structure representing
%environmental information

%ENV_DATA is a data structure containing information about the model
   %environment
   %    ENV_DATA.shape - shape of environment - FIXED AS CUBIC
   %    ENV_DATA.units - FIXED AS micrometre
   %    ENV_DATA.bm_size - length of environment edge in micrometre
   %    ENV_DATA.food - the total number of food in the 

   
%Modified by Tiantian Xian & Yiting Zheng
%Modified March 2019


global ENV_DATA

ENV_DATA.shape='cubic';
ENV_DATA.units='micrometres';
ENV_DATA.bm_size=size;   %The size of the Petri dish
ENV_DATA.food=food;       % Total number of food in the Petri dish
